# Investor SQL statements
investor_by_id = 'SELECT name, address, status, id FROM investor WHERE id = %s'
get_investors_by_name_sql = 'SELECT name, address, status, id FROM investor WHERE name = %s'
create_investor = 'INSERT into investor (name, address, status) VALUES (%s, %s, %s)'
update_investor_name = 'UPDATE investor set name = %s WHERE id = %s'
update_investor_address = 'UPDATE investor set address = %s WHERE id = %s'
update_investor_status = 'UPDATE investor set status = %s WHERE id = %s'
Delete_investor_id = 'DELETE FROM investor WHERE id= %s'

#Account SQL Statements
account_by_id = 'SELECT investor_id, balance, id FROM account WHERE id = %s'
get_account_by_investor_id_sql = 'SELECT investor_id, balance, id FROM account WHERE investor_id = %s'
create_accoount = 'INSERT into account (investor_id, balance) VALUES (%s, %s)'
update_account_investor_id = 'UPDATE account set investor_id = %s WHERE id = %s'
update_account_balance = 'UPDATE account set balance = %s WHERE id = %s'
Delete_account_id = 'DELETE FROM account WHERE id= %s'

#Portfolio SQL Statements
portfolio_by_id = 'SELECT account_id, ticker, quantity, id FROM portfolio WHERE id = %s'
get_portfolio_by_account_id_sql = 'SELECT account_id, ticker,quantity, id FROM portfolio WHERE account_id = %s'
create_portfolio = 'INSERT into portolio (account_id, ticker,quantity) VALUES (%s, %s, %s)'
update_porfolio_account_id= 'UPDATE portfolio set account_id = %s WHERE id = %s'
update_portfolio_ticker = 'UPDATE portfolio set ticker = %s WHERE id = %s'
update_portfolio_quantity= 'UPDATE portfolio set quantity = %s WHERE id = %s'
Delete_investor_id = 'DELETE FROM portfolio WHERE id= %s'