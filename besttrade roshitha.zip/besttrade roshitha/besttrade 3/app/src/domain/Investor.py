import typing as t

class Investor():
    def init(self, name: str, address: t.Optional[str], invested_amount: int, status: str, id: int = -1):
        self.id = id
        self.name = name
        self.address = address
        self.invested_amount = invested_amount
        self.status = status

    def str(self): 
        return f'[id: {self.id}, name: {self.name}, address: {self.address}, invested_amount: {self.invested_amount} status: {self.status}]'

    @staticmethod
    def from_dict(dict):
        if dict.get('name') is None or dict.get('status') is None or dict.get('address') is None: # all attributes are required
            raise Exception(f'Can not create Investor object from dict {dict}: missing required attributes')
        else:
            return Investor(dict.get('name'), dict.get('address'), dict.get('status'))