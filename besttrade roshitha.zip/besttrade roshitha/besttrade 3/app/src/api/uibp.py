from flask import Blueprint, render_template
from app.src.domain.Investor import Investor
import app.src.db.investordao as investordao
from app.src.domain.account import Account
import app.src.db.accountdao as accountdao

uibp = Blueprint('ui',__name__, url_prefix = '/ui')

@uibp.route('/', methods = ['GET'])
def main():
    return render_template('home.html') 

@uibp.route('/about', methods = ['GET'])
def about():
    return render_template('about.html') 

@uibp.route('/investors', methods = ['GET'])
def investor_all():
    investors = investordao.get_all_investor()
    return render_template('investors.html', investors = investors)  

@uibp.route('/accounts', methods = ['GET'])
def accounts_all():
    accounts = accountdao.get_all_accounts()
    return render_template('accounts.html', accounts = accounts)