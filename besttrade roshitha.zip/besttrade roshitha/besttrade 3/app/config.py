db_config = {
    'host': '',
    'port': 0,
    'user': '',
    'password': '',
    'db': ''
}